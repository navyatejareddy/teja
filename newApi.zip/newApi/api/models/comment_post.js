const mongoose = require('mongoose');
const comment_postSchema = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    postTitle: { type: String, required: true },
    postImage: { type: String },
    postDate:{ type: String, required: true },
    user_id:{ type: String, required: true },
    user_name:{type: String, required: true},
    postSkills:{type: String, required: true},
    postDescription:{type: String, required: true},
    postJobType:{type: String, required: true},
    comments:[{
        comm_userName: {type: String},
        comm_userUrl: {type: String},
        user_id: {type: String},
        created: { type: Date,default: Date.now},
        comm_tTitle:{type: String}
    }]
});

module.exports = mongoose.model('Comment_post', comment_postSchema);